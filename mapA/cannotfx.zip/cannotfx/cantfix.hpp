/**
 * implement a container like std::map
 */
#ifndef SJTU_MAP_HPP
#define SJTU_MAP_HPP

// only for std::less<T>
#include <functional>
#include <cstddef>
#include "utility.hpp"
#include "exceptions.hpp"


#include<iostream> //////////////

namespace sjtu {

template<
	class Key,
	class T,
	class Compare = std::less<Key>
> class map {

	enum colT{RED, BLACK};

	struct Node{
		pair<const Key, T> *num;
		Node *l, *r, *fa;
		colT col;
		Node() {
			num = NULL; l = r = fa = NULL; 
			col = RED;
		}
		Node(const pair<const Key, T> &x, Node *ls = NULL, Node *rs = NULL, colT c = RED): l(ls), r(rs), col(c) {
			num = new pair<const Key, T>(x);
		}
		~Node() {
			if(num) delete num;
		}

		/*
		Node(const Node &b) {
			std::cerr<<"Node copy construct................\n";
		}

		Node &operator= (const Node& b) {
			std::cerr<<"Node operator = ...................\n";
		}
		*/
		
	};

	Node *root, *ed;
	size_t sz;

public:

	/**
	 * the internal type of data.
	 * it should have a default constructor, a copy constructor.
	 * You can use sjtu::map as value_type by typedef.
	 */
	typedef pair<const Key, T> value_type;
	/**
	 * see BidirectionalIterator at CppReference for help.
	 *
	 * if there is anything wrong throw invalid_iterator.
	 *     like it = map.begin(); --it;
	 *       or it = map.end(); ++end();
	 */
	class const_iterator;
	class iterator {
	private:
		/**
		 * TODO add data members
		 *   just add whatever you want.
		 */
		map *bel;
		Node *p;
		bool ok;

		friend class map;

	public:
		iterator(map *bel = NULL, Node *p = NULL):bel(bel), p(p) {
			ok = 1;
		}
		iterator(const iterator &other) {
			bel = other.bel;
			p = other.p;
			ok = other.ok;
		}
		/**
		 * return a new iterator which pointer n-next elements
		 *   even if there are not enough elements, just return the answer.
		 * as well as operator-
		 */
		/**
		 * TODO iter++
		 */
		iterator operator++(int) {
			if(ok == 0) throw runtime_error();
			iterator rs = *this;
			if(*this == bel->end()) throw index_out_of_bound();
			Node *pos = p, *lst = p;
			while(pos != bel->root && (pos->r == NULL || pos->r == lst)) {
				lst = pos; pos = pos->fa;
				if(pos->r != lst) {
					p = pos;
					return rs;
				}
			}
			pos = pos->r;
			while(pos->l) pos = pos->l;
			p = pos;
			return rs;
		}
		/**
		 * TODO ++iter
		 */
		iterator & operator++() {
			if(ok == 0) throw runtime_error();
			if(*this == bel->end()) throw index_out_of_bound();
			Node *pos = p, *lst = p;
			while(pos != bel->root && (pos->r == NULL || pos->r == lst)) {
				lst = pos; pos = pos->fa;
				if(pos->r != lst) {
					p = pos;
					return *this;
				}
			}
			pos = pos->r;
			while(pos->l) pos = pos->l;
			p = pos;
			return *this;
		}
		/**
		 * TODO iter--
		 */
		iterator operator--(int) {
			if(ok == 0) throw runtime_error();
			iterator rs = *this;
			if(*this == bel->begin()) throw index_out_of_bound();
			Node *pos = p, *lst = p;
			while(pos != bel->root && (pos->l == NULL || pos->l == lst)) {
				lst = pos; pos = pos->fa;
				if(pos->l != lst) {
					p = pos;
					return rs;
				}
			}
			pos = pos->l;
			while(pos->r) pos = pos->r;
			p = pos;
			return rs;
		}
		/**
		 * TODO --iter
		 */
		iterator & operator--() {
			if(ok == 0) throw runtime_error();
			if(*this == bel->begin()) throw index_out_of_bound();
			Node *pos = p, *lst = p;
			while(pos != bel->root && (pos->l == NULL || pos->l == lst)) {
				lst = pos; pos = pos->fa;
				if(pos->l != lst) {
					p = pos;
					return *this;
				}
			}
			pos = pos->l;
			while(pos->r) pos = pos->r;
			p = pos;
			return *this;
		}
		/**
		 * a operator to check whether two iterators are same (pointing to the same memory).
		 */
		value_type & operator*() const {
			if(ok == 0 || *this == bel->end()) throw index_out_of_bound();
			return *(p->num);
		}
		bool operator==(const iterator &rhs) const {
			if(this->ok == 0 || rhs.ok == 0) throw runtime_error();
			return this->bel == rhs.bel && this->p == rhs.p;
		}
		bool operator==(const const_iterator &rhs) const {
			if(this->ok == 0 || rhs.ok == 0) throw runtime_error();
			return this->bel == rhs.bel && this->p == rhs.p;
		}
		/**
		 * some other operator for iterator.
		 */
		bool operator!=(const iterator &rhs) const {
			return !operator==(rhs);
		}
		bool operator!=(const const_iterator &rhs) const {
			return !operator==(rhs);
		}

		/**
		 * for the support of it->first. 
		 * See <http://kelvinh.github.io/blog/2013/11/20/overloading-of-member-access-operator-dash-greater-than-symbol-in-cpp/> for help.
		 */
		value_type* operator->() const noexcept {
			return p->num;
		}
	};
	class const_iterator {
		// it should has similar member method as iterator.
		//  and it should be able to construct from an iterator.
	private:
			// data members.
		const map *bel;
		Node *p;
		bool ok;
		
		friend class map;
	public:
		const_iterator(const map *bel = NULL, Node *p = NULL):bel(bel), p(p) {
			ok = 1;
		}
		const_iterator(const const_iterator &other) {
			bel = other.bel;
			p = other.p;
			ok = other.ok;
		}
		const_iterator(const iterator &other){
			bel = other.bel;
			p = other.p;
			ok = other.ok;
		}
		const_iterator operator++(int) {
			if(ok == 0) throw runtime_error();
			const_iterator rs = *this;
			if(*this == bel->cend()) throw index_out_of_bound();
			Node *pos = p, *lst = p;
			while(pos != bel->root && (pos->r == NULL || pos->r == lst)) {
				lst = pos; pos = pos->fa;
				if(pos->r != lst) {
					p = pos;
					return rs;
				}
			}
			pos = pos->r;
			while(pos->l) pos = pos->l;
			p = pos;
			return rs;
		}
		const_iterator & operator++() {
			if(ok == 0) throw runtime_error();
			if(*this == bel->cend()) throw index_out_of_bound();
			Node *pos = p, *lst = p;
			while(pos != bel->root && (pos->r == NULL || pos->r == lst)) {
				lst = pos; pos = pos->fa;
				if(pos->r != lst) {
					p = pos;
					return *this;
				}
			}
			pos = pos->r;
			while(pos->l) pos = pos->l;
			p = pos;
			return *this;
		}
		const_iterator operator--(int) {
			if(ok == 0) throw runtime_error();
			const_iterator rs = *this;
			if(*this == bel->cbegin()) throw index_out_of_bound();
			Node *pos = p, *lst = p;
			while(pos != bel->root && (pos->l == NULL || pos->l == lst)) {
				lst = pos; pos = pos->fa;
				if(pos->l != lst) {
					p = pos;
					return rs;
				}
			}
			pos = pos->l;
			while(pos->r) pos = pos->r;
			p = pos;
			return rs;
		}
		const_iterator & operator--() {
			if(ok == 0) throw runtime_error();
			if(*this == bel->cbegin()) throw index_out_of_bound();
			Node *pos = p, *lst = p;
			while(pos != bel->root && (pos->l == NULL || pos->l == lst)) {
				lst = pos; pos = pos->fa;
				if(pos->l != lst) {
					p = pos;
					return *this;
				}
			}
			pos = pos->l;
			while(pos->r) pos = pos->r;
			p = pos;
			return *this;
		}
		value_type & operator*() const {
			if(ok == 0 || *this == bel->cend()) throw index_out_of_bound();
			return *(p->num);
		}
		bool operator==(const iterator &rhs) const {
			if(this->ok == 0 || rhs.ok == 0) throw runtime_error();
			return this->bel == rhs.bel && this->p == rhs.p;
		}
		bool operator==(const const_iterator &rhs) const {
			if(this->ok == 0 || rhs.ok == 0) throw runtime_error();
			return this->bel == rhs.bel && this->p == rhs.p;
		}
		bool operator!=(const iterator &rhs) const {
			return !operator==(rhs);
		}
		bool operator!=(const const_iterator &rhs) const {
			return !operator==(rhs);
		}
		value_type* operator->() const noexcept {
			return p->num;
		}
		/*
		void debug() {
			std::cerr<<"const_iterator: "<< p << " " << ok << "\n";
		}
		*/
	};

private:

	void swap(value_type *&a, value_type *&b) {
		value_type *t = a; a = b; b = t;
	}

	Node *copy(Node *f, Node *t) {
		if(t == NULL) return NULL;
		Node *pos = t->num? new Node(*(t->num)) : new Node;
		pos->fa = f;
		pos->col = t->col;
		pos->l = copy(pos, t->l);
		pos->r = copy(pos, t->r);
		return pos;
	}

	void get_empty(Node *pos) {
		if(pos == NULL) return;
		get_empty(pos->l);
		get_empty(pos->r);
		delete pos;
	}

	Node *findend() const{
		Node *p = root;
		while(p->r) p = p->r;
		return p;
	}

	void LL(Node *g) {
		Node *gg = g->fa, *p = g->l, *t = p->l;
		g->l = p->r; if(p->r) p->r->fa = g;
		p->r = g; if(g) g->fa = p;
		p->fa = gg; 
		if(gg) {
			if(gg->l == g) gg->l = p;
			else gg->r = p;
		}
		else root = p;
		colT tmp= p->col; p->col = g->col; g->col = tmp;
	}

	void RR(Node *g) {
		Node *gg = g->fa, *p = g->r, *t = p->r;
		g->r = p->l; if(p->l) p->l->fa = g;
		p->l = g; if(g) g->fa = p;
		p->fa = gg; 
		if(gg) {
			if(gg->l == g) gg->l = p;
			else gg->r = p;
		}
		else root = p;
		colT tmp= p->col; p->col = g->col; g->col = tmp;
	}

	void LR(Node *g) {
		Node *gg = g->fa, *p = g->l, *t = p->r;
		p->r = t->l; if(t->l) t->l->fa = p;
		g->l = t->r; if(t->r) t->r->fa = g;
		t->l = p; if(p) p->fa = t;
		t->r = g; if(g) g->fa = t;
		t->fa = gg;
		if(gg) {
			if(gg->l == g) gg->l = t;
			else gg->r = t;
		}
		else root = t;
		colT tmp= t->col; t->col = g->col; g->col = tmp;
	}

	void RL(Node *g) {
		Node *gg = g->fa, *p = g->r, *t = p->l;
		p->l = t->r; if(t->r) t->r->fa = p;
		g->r = t->l; if(t->l) t->l->fa = g;
		t->r = p; if(p) p->fa = t;
		t->l = g; if(g) g->fa = t;
		t->fa = gg;
		if(gg) {
			if(gg->l == g) gg->l = t;
			else gg->r = t;
		}
		else root = t;
		colT tmp= t->col; t->col = g->col; g->col = tmp;
	}

	bool key_cmp(const value_type *a, const Key *key) const{ //a > b
		if(a == NULL && key) return 1;
		if(key == NULL) return 0;
		return Compare()(*key, a->first);
	}
	
	bool xd(const value_type *a, const Key *key) const{
		if(a == NULL && key == NULL) return 1;
		if(a == NULL || key == NULL) return 0;
		return !(Compare()(*key, a->first) || Compare()(a->first, *key));
	}

	void swapNode(Node *a, Node *b) {
		Node *t = a->fa; a->fa = b->fa; b->fa = t;
		if(a->fa == NULL) root = a;
		else {
			if(a->fa->l == b) a->fa->l = a;
			else a->fa->r = a;
		}
		if(b->fa == NULL) root = b;
		else {
			if(b->fa->l == a) b->fa->l = b;
			else b->fa->r = b;
		}
		t = a->l; a->l = b->l; b->l = t;
		t = a->r; a->r = b->r; b->r = t;
		if(a->l) a->l->fa = a; if(a->r) a->r->fa = a;
		if(b->l) b->l->fa = b; if(b->r) b->r->fa = b;
		colT tmp = a->col; a->col = b->col; b->col = tmp;
	}

	void insertAdjust(Node *&g, Node *&p, Node *&t) {
		if(p->col == BLACK) return;
		if(p == root) {
			p->col = BLACK;
			return;
		}
		if(g->l == p) {
			if(p->l == t) LL(g); 
			else LR(g);
		}
		else if(p->r == t) RR(g);
		else RL(g);
		p = (t == root)? root : t->fa;
		g = (p == root)? root : p->fa;
	}

	void removeAdjust(Node *&p, Node *&c, Node *&t, const Key *k) {
		if(c->col == RED) return;
		if(c == root) {
			if(c->l && c->r && c->l->col == c->r->col) {
				c->col = RED;
				c->l->col = c->r->col = BLACK;
				return;
			}
		}
		if(c == root) std::cerr<<"QAQ\n";
		if(((c->l && c->l->col == BLACK) || c->l == NULL) && ((c->r && c->r->col == BLACK) || c->r == NULL)) {
			if(((t->l && t->l->col == BLACK) || t->l == NULL) && ((t->r && t->r->col == BLACK) || t->r == NULL)) {
				p->col = BLACK;
				c->col = t->col = RED;
			}
			else {
				if(p->l == t) {
					if(t->l && t->l->col == RED) {
						t->l->col = BLACK;
						LL(p);
					}
					else {
						LR(p);
						p->col = BLACK;
					}
				}
				else {
					if(t->r && t->r->col == RED) {
						t->r->col = BLACK;
						RR(p);
					}
					else {
						RL(p);
						p->col = BLACK;
					}
				}
				c->col = RED;
			}
		}
		else {
			if(xd(c->num, k)) {
				if(c->l && c->r) {
					if(c->r->col == BLACK) LL(c);
					if(c == root) {p = t = root;}
					else {
						p = c->fa;
						t = (c == p->l)? p->r : p->l;
					}
					return;
				}
				if(c->l) LL(c);
				else RR(c);
			}
			else {
				p = c;
				c = key_cmp(p->num, k)? p->l : p->r;
				t = (c == p->l)? p->r : p->l;
				if(c->col == BLACK) {
					if(t == p->l) LL(p); else RR(p);
					if(c == root) {p = t = root;}
					else {
						p = c->fa;
						t = (c == p->l)? p->r : p->l;
					}
					removeAdjust(p, c, t, k);
				}
			}
		}
		if(c == root) {p = t = root;}
		else {
			p = c->fa;
			t = (c == p->l)? p->r : p->l;
		}
	}

	void solve(Node *p) {
		Node *c = NULL, *t;
		while(c != root && (c == NULL || c->col == BLACK)) {
			if(c) p = c->fa;
			t = (c == p->l)? p->r : p->l;
			if(!t) {
				c = p; continue;
			}
			if(t->col == RED) {
				if(c == p->l) RR(p);
				else LL(p);
				if(c) p = c->fa;
				t = (c == p->l)? p->r : p->l;
			}
			if(!t) {
				c = p; continue;
			}
			if((t->l == NULL || t->l->col == BLACK) && (t->r == NULL || t->r->col == BLACK)) {
				t->col = RED;
				c = p;
			}
			else {
				if(c == p->l) {
					if(t->r == NULL || t->r->col == BLACK) {
						LL(t); 
						t = (c == p->l)? p->r : p->l;
					}
					RR(p);
					t->r->col = RED;
					c = root;
				}
				else {
					if(t->l == NULL || t->l->col == BLACK) {
						RR(t);
						t = (c == p->l)? p->r : p->l;
					}
					LL(p);
					t->l->col = RED;
					c = root;
				}
			}
		}
		if(c) c->col = BLACK;
	}

public:
	/**
	 * TODO two constructors
	 */
	map() {
		root = ed = new Node;
		root->col = BLACK;
		sz = 1;
	}
	map(const map &other) {
		sz = other.sz;
		root = copy(NULL, other.root);
		ed = findend();		
	}
	/**
	 * TODO assignment operator
	 */
	map & operator=(const map &other) {
		if(&other == this) return *this;
		this->~map();
		sz = other.sz;
		root = copy(NULL, other.root);
		ed = findend();
		return *this;
	}
	/**
	 * TODO Destructors
	 */
	~map() {
		get_empty(root);
		sz = 0; root = NULL;
	}
	/**
	 * TODO
	 * access specified element with bounds checking
	 * Returns a reference to the mapped value of the element with key equivalent to key.
	 * If no such element exists, an exception of type 'index_out_of_bound'
	 */
	T & at(const Key &key) {
		iterator rs = find(key);
		if(rs == end()) throw index_out_of_bound();
		return rs.p->num->second;
	}
	const T & at(const Key &key) const {
		const_iterator rs = find(key);
		if(rs == cend()) throw index_out_of_bound();
		return rs.p->num->second;
	}
	/**
	 * TODO
	 * access specified element 
	 * Returns a reference to the value that is mapped to a key equivalent to key,
	 *   performing an insertion if such key does not already exist.
	 */
	T & operator[](const Key &key) {
		Node *pos = root;
		while(pos && (!xd(pos->num, &key))) {
			pos = key_cmp(pos->num, &key)? pos->l : pos->r;
		}
		if(!pos) return insert(value_type(key, T())).first.p->num->second;
		return pos->num->second;
	}
	/**
	 * behave like at() throw index_out_of_bound if such key does not exist.
	 */
	const T & operator[](const Key &key) const {
		Node *pos = root;
		while(pos && (!xd(pos->num, &key))) {
			pos = key_cmp(pos->num, &key)? pos->l : pos->r;
		}
		if(!pos) throw index_out_of_bound();
		return pos->num->second;
	}
	/**
	 * return a iterator to the beginning
	 */
	iterator begin() {
		Node *t = root;
		while(t->l) t = t->l;
		return iterator(this, t);
	}
	const_iterator cbegin() const {
		Node *t = root;
		while(t->l) t = t->l;
		return const_iterator(this, t);
	}
	/**
	 * return a iterator to the end
	 * in fact, it returns past-the-end.
	 */
	iterator end() {
		return iterator(this, ed);
	}
	const_iterator cend() const {
		return const_iterator(this, ed);
	}
	/**
	 * checks whether the container is empty
	 * return true if empty, otherwise false.
	 */
	bool empty() const { return sz == 1; }
	/**
	 * returns the number of elements.
	 */
	size_t size() const { return sz - 1; }
	/**
	 * clears the contents
	 */
	void clear() { 
		this->~map(); 
		ed = root = new Node;
		root->col = BLACK;
		sz = 1;
	}

	/**
	 * insert an element.
	 * return a pair, the first of the pair is
	 *   the iterator to the new element (or the element that prevented the insertion), 
	 *   the second one is true if insert successfully, or false.
	 */
	pair<iterator, bool> insert(const value_type &value) {
		//puts("in insert"); ////////////////////////////
		iterator o = find(value.first);
		if(o != end()) return pair<iterator, bool> (o, false);
		Node *t, *p, *g;
		t = p = g = root;
		++sz; 
		while(1) {
			if(!t) {
				t = new Node(value);
				t->fa = p;
				if(key_cmp(p->num, &value.first)) p->l = t; else p->r = t;
				insertAdjust(g, p, t);
				root->col = BLACK;
				//puts("out insert"); ////////////////////////////
				ed = findend();
				return pair<iterator, bool> (iterator(this, t), true);
			}
			if(t->l && t->l->col == RED && t->r && t->r->col == RED) {
				t->l->col = t->r->col = BLACK;
				t->col = RED;
				insertAdjust(g, p, t);
			}
			g = p; p = t;
			t = key_cmp(t->num, &value.first)? t->l : t->r;
		}
	}
	/**
	 * erase the element at pos.
	 *
	 * throw if pos pointed to a bad element (pos == this->end() || pos points an element out of this)
	 */
	void erase(iterator pos) {
		//puts("in erase");
		if(pos.ok == 0 || (pos.bel != this)) throw runtime_error();
		if(pos == end()) throw index_out_of_bound();
		--sz;
		Key *k = new Key(pos.p->num->first);
		Node *t, *p, *c;
		t = p = c = root;
		while(1) {
			removeAdjust(p, c, t, k);
			if(xd(c->num, k) && c->l && c->r) {
				Node *tmp = c->r;
				while(tmp->l) tmp = tmp->l;
				swapNode(c, tmp);
				p = c->fa;
				t = (c == p->l)? p->r : p->l;
				if(p->l == c) p->l = c->r;
				else p->r = c->r;
				if(c->col == BLACK && c->r == NULL) solve(p);
				else if(c->r) {
					c->r->fa = p;
					if(c->col == BLACK) c->r->col = BLACK;
				}
				delete c;
				break;
			}
			if(xd(c->num, k)) {
				if(p == c) std::cerr<<"opp\n";
				delete c;
				if(p->l == c) p->l = NULL;
				else p->r = NULL;
				root->col = BLACK;
				break;
			}
			p = c;
			c = key_cmp(p->num, k)? p->l : p->r; 
			t = (c == p->l)? p->r : p->l;
		}
		if(k) delete k;
		ed = findend();
		pos.ok = 0;
		//puts("out erase");////////////
	}
	
	/**
	 * Returns the number of elements with key 
	 *   that compares equivalent to the specified argument,
	 *   which is either 1 or 0 
	 *     since this container does not allow duplicates.
	 * The default method of check the equivalence is !(a < b || b > a)
	 */
	size_t count(const Key &key) const {
		if(find(key) != cend()) return 1;
		return 0;
	}
	/**
	 * Finds an element with key equivalent to key.
	 * key value of the element to search for.
	 * Iterator to an element with key equivalent to key.
	 *   If no such element is found, past-the-end (see end()) iterator is returned.
	 */
	iterator find(const Key &key) {
		//puts("in find"); /////////////////////
		Node *pos = root;
		while(pos && (!xd(pos->num, &key))) {
			pos = key_cmp(pos->num, &key)? pos->l : pos->r;
		}
		if(!pos) return end();
		//puts("out find"); /////////////////////
		return iterator(this, pos);
	}
	const_iterator find(const Key &key) const {
		Node *pos = root;
		while(pos && (!xd(pos->num, &key))) {
			pos = key_cmp(pos->num, &key)? pos->l : pos->r;
		}
		if(!pos) return cend();
		return const_iterator(this, pos);
	}
	// /*
	void dfs(Node *pos) const {
		std::cerr << pos << " " << pos->fa << " " << pos->col << "    ";
		std::cerr << "(" << pos->l << " " << pos->r << ")  "; 
		if(pos->num) std::cerr << pos->num->first ;
		std::cerr << "\n";
		if(pos->l) dfs(pos->l);
		if(pos->r) dfs(pos->r);
	}

	void debug() const{
		//return;
		std::cerr<<"debug:\n";
		dfs(root);
	}
	// */
};

}

#endif